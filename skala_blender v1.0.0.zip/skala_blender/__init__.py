bl_info = {
    "name": "Skala",
    "author": "Your Name",
    "version": (1, 0, 0),
    "blender": (3, 6, 0),
    "location": "3D Viewport > Header",
    "description": "Scales the 3D viewport so model geometry is displayed at true physical size on screen.",
    "category": "3D View",
}

import os

import bpy
import bpy.utils.previews
import mathutils
from bpy_extras import view3d_utils

from . import dpi_utils

# How often (seconds) to check whether the user has zoomed away from
# the locked 1:1 scale. The check itself is a single float comparison
# -- computationally free -- so this can run often without meaningful
# cost; 30ms gives near-instant revert without any real resource use.
CHECK_INTERVAL = 0.03
# Fractional drift in view_distance before we consider the user to
# have zoomed (vs. floating-point/redraw jitter at the exact locked
# value).
DRIFT_TOLERANCE = 0.02

_watch_state = {}
_custom_icons = None


def _cm_per_blender_unit(scene):
    """scale_length expresses meters-per-Blender-Unit regardless of the
    display unit system (metric/imperial/none) -- multiply by 100 for
    real-world centimeters per Blender Unit."""
    return scene.unit_settings.scale_length * 100.0


def _measure_pixels_per_bu(region, region_3d):
    """
    Ground-truth measurement of the current viewport's pixels-per-
    Blender-Unit, using Blender's own tested projection utility
    (bpy_extras.view3d_utils) rather than hand-rolling projection
    matrix math ourselves.
    """
    origin = region_3d.view_location.copy()
    right_dir = region_3d.view_rotation @ mathutils.Vector((1.0, 0.0, 0.0))
    p0 = origin
    p1 = origin + right_dir

    s0 = view3d_utils.location_3d_to_region_2d(region, region_3d, p0)
    s1 = view3d_utils.location_3d_to_region_2d(region, region_3d, p1)
    if s0 is None or s1 is None:
        return None
    return (s1 - s0).length  # pixels per 1 Blender Unit, along view-right


class SKALA_OT_scale_to_reality(bpy.types.Operator):
    """Scale the viewport so model geometry is displayed at true physical size"""
    bl_idname = "skala.scale_to_reality"
    bl_label = "Skala: Scale to Reality"
    bl_options = {"REGISTER"}

    def execute(self, context):
        area = context.area
        region = context.region
        region_3d = context.space_data.region_3d if context.space_data else None

        if not region_3d or area.type != 'VIEW_3D':
            self.report({'WARNING'}, "Run this from inside a 3D Viewport.")
            return {'CANCELLED'}

        previous_perspective = region_3d.view_perspective
        if region_3d.view_perspective != 'ORTHO':
            # Deliberately does NOT change viewing angle/rotation --
            # orthographic projection preserves true scale at any
            # angle, so there's no need to snap to a canonical view.
            region_3d.view_perspective = 'ORTHO'

        try:
            dpi_result = dpi_utils.get_screen_dpi()
        except Exception as e:
            self.report({'ERROR'}, f"Skala: DPI detection failed: {e}")
            return {'CANCELLED'}

        pixels_per_cm = dpi_result.pixels_per_cm_y
        cm_per_bu = _cm_per_blender_unit(context.scene)
        target_pixels_per_bu = pixels_per_cm * cm_per_bu

        current_pixels_per_bu = _measure_pixels_per_bu(region, region_3d)
        if not current_pixels_per_bu:
            self.report({'WARNING'}, "Skala: couldn't measure current viewport scale.")
            return {'CANCELLED'}

        ratio = current_pixels_per_bu / target_pixels_per_bu
        region_3d.view_distance = region_3d.view_distance * ratio
        area.tag_redraw()

        # Changing view_distance from Python does NOT synchronously
        # recompute the region's projection matrices -- Blender only
        # does that during its own internal redraw cycle. Without
        # forcing one here, an immediate re-measurement would read
        # stale, pre-correction matrices (confirmed via diagnostics:
        # pass 1 and pass 2 came back virtually identical despite the
        # view_distance change in between). redraw_timer forces that
        # redraw to happen synchronously before we measure again.
        bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=1)

        # Ortho zoom should scale exactly linearly with view_distance,
        # so one pass should already be correct -- but a second
        # measurement/correction pass costs nothing and removes any
        # doubt about rounding, now that the redraw above ensures this
        # measurement actually reflects the correction.
        current_pixels_per_bu_2 = _measure_pixels_per_bu(region, region_3d)
        if current_pixels_per_bu_2:
            ratio2 = current_pixels_per_bu_2 / target_pixels_per_bu
            if abs(ratio2 - 1.0) > 0.001:
                region_3d.view_distance = region_3d.view_distance * ratio2
                area.tag_redraw()
                bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=1)

        # --- Diagnostics: print to the system console so we can see
        # exactly which number is wrong instead of guessing further.
        # On Mac: launch Blender from Terminal (e.g.
        # /Applications/Blender.app/Contents/MacOS/Blender) to see
        # this output.
        print("=== Skala diagnostics [build: redraw-fix-1] ===")
        print(f"DPI method: {dpi_result.method}")
        print(f"DPI raw_info: {dpi_result.raw_info}")
        print(f"dpi_x, dpi_y: {dpi_result.dpi_x:.2f}, {dpi_result.dpi_y:.2f}")
        print(f"pixels_per_cm (used, from dpi_y): {pixels_per_cm:.4f}")
        print(f"scene.unit_settings.scale_length: {context.scene.unit_settings.scale_length}")
        print(f"cm_per_bu: {cm_per_bu}")
        print(f"target_pixels_per_bu: {target_pixels_per_bu:.4f}")
        print(f"region.width x region.height (px): {region.width} x {region.height}")
        print(f"measured_pixels_per_bu (pass 1, before correction): {current_pixels_per_bu:.4f}")
        print(f"measured_pixels_per_bu (pass 2, after correction + forced redraw): {current_pixels_per_bu_2}")
        print(f"final view_distance: {region_3d.view_distance:.4f}")
        print("=== end Skala diagnostics ===")

        _start_zoom_watch(area, region_3d, previous_perspective)
        return {'FINISHED'}


def _start_zoom_watch(area, region_3d, previous_perspective):
    """
    Watches for the user zooming away from the locked 1:1 scale (by
    any means -- scroll wheel, trackpad pinch, Numpad +/-, View
    Selected, Home, etc: we watch the outcome, not the input method)
    and reverts to whatever projection mode was active before Skala
    locked it to orthographic. Rotating freely is fine and does NOT
    revert the lock -- orthographic projection stays scale-accurate
    at any viewing angle.
    """
    key = id(region_3d)
    _watch_state[key] = {
        "area": area,
        "region_3d": region_3d,
        "locked_distance": region_3d.view_distance,
        "previous_perspective": previous_perspective,
    }

    def _check():
        state = _watch_state.get(key)
        if state is None:
            return None  # already stopped elsewhere

        try:
            rv3d = state["region_3d"]
            area_ref = state["area"]
            # Accessing an attribute on a freed Blender struct raises
            # ReferenceError -- our signal that the viewport/area is
            # gone (closed, workspace switched, file changed, etc).
            current_distance = rv3d.view_distance
        except ReferenceError:
            _watch_state.pop(key, None)
            return None

        locked = state["locked_distance"]
        if not locked:
            _watch_state.pop(key, None)
            return None

        drift = abs(current_distance - locked) / locked
        if drift > DRIFT_TOLERANCE:
            try:
                rv3d.view_perspective = state["previous_perspective"]
                area_ref.tag_redraw()
            except ReferenceError:
                pass
            _watch_state.pop(key, None)
            return None  # stop the timer

        return CHECK_INTERVAL  # keep watching

    bpy.app.timers.register(_check, first_interval=CHECK_INTERVAL)


def _draw_header_button(self, context):
    if context.area.type != 'VIEW_3D':
        return
    layout = self.layout
    if _custom_icons and "skala_banana" in _custom_icons:
        layout.operator(
            SKALA_OT_scale_to_reality.bl_idname, text="",
            icon_value=_custom_icons["skala_banana"].icon_id,
        )
    else:
        layout.operator(
            SKALA_OT_scale_to_reality.bl_idname, text="", icon='FULLSCREEN_ENTER'
        )


def register():
    global _custom_icons
    _custom_icons = bpy.utils.previews.new()
    icon_path = os.path.join(os.path.dirname(__file__), "icons", "skala_banana.png")
    if os.path.exists(icon_path):
        _custom_icons.load("skala_banana", icon_path, 'IMAGE')

    bpy.utils.register_class(SKALA_OT_scale_to_reality)
    bpy.types.VIEW3D_HT_header.append(_draw_header_button)


def unregister():
    global _custom_icons
    bpy.types.VIEW3D_HT_header.remove(_draw_header_button)
    bpy.utils.unregister_class(SKALA_OT_scale_to_reality)

    if _custom_icons:
        bpy.utils.previews.remove(_custom_icons)
        _custom_icons = None

    _watch_state.clear()
